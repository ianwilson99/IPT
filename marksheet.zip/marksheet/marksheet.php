<!DOCTYPE html>
<html>
<head>
     <title></title>
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>
<body>
<h2 style="text-align:center">Percentage Calculator</h2>
<div class="container" style="padding-left:200px;">
<form method="get" class="form-horizontal">
<div class="form-group">
<div class="col-sm-10">
<input class="form-control" type="text" name="sub_1" placeholder="Enter Marks">
</div>
<div class="col-sm-10">
<input class="form-control" type="text" name="sub_2" placeholder="Enter Marks">
</div>
<div class="col-sm-10">
<input class="form-control" type="text" name="sub_3" placeholder="Enter Marks">
</div>
<div class="col-sm-10">
<input class="form-control" type="text" name="sub_4" placeholder="Enter Marks">
</div>
<div class="col-sm-10">
<input class="form-control" type="text" name="sub_5" placeholder="Enter Marks">
</div>
<div class="col-sm-10">
<input class="btn btn-default" type="submit" name="submit" value="Calculate">
</div>
</div>
</form>
<div class="container">
<?php
if(isset($_GET['submit']))
{
	$sub1=$_GET['sub_1'];
	$sub2=$_GET['sub_2'];
	$sub3=$_GET['sub_3'];
	$sub4=$_GET['sub_4'];
	$sub5=$_GET['sub_5'];
	
	$obtain_marks=$sub1+$sub2+$sub3+$sub4+$sub5;
	$totalmarks=500;
	$percentage=($obtain_marks/$totalmarks)*100;
	
	
	if($percentage >=90)
	{
		$out= "A+";
	}
	else if($percentage >=80)
	{
		$out= "A";
	}
	else if($percentage >=70)
	{
		$out= "A";
	}
	else if($percentage >=60)
	{
		$out= "B";
	}
	else if($percentage >=45)
	{
		$out= "C";
	}
	else
	{
		$out= "Fail";
	}
}
?>
<div class="container">
<h2>Result</h2>
<table class="table table-striped">
<tr>
<tr>
<th>
Subjects
</th>
<th>
Marks
</th>
</tr>
<tr>
<td>Subject 1</td>
<td><?php echo $sub1; ?></td>
</tr>
<tr>
<td>Subject 2</td>
<td><?php echo $sub2; ?></td>
</tr>
<tr>
<td>Subject 3</td>
<td><?php echo $sub3; ?></td>
</tr>
<tr>
<td>Subject 4</td>
<td><?php echo $sub4; ?></td>
</tr>
<tr>
<td>Subject 5</td>
<td><?php echo $sub5; ?></td>
</tr>
<tr>
<th>Obtain Marks</th>
<th><?php echo $obtain_marks; ?></th>
</tr>
<tr>
<td>Percentage</td>
<th><?php echo $percentage; echo "%"; ?></th>
</tr>
<tr>
<th>Grade</th>
<th><?php echo $out; ?></th>
</tr>
</tr>
</tr>
</table>
</div>
</body>
</html>